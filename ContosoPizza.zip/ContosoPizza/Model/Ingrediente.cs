namespace ContosoPizza.Models;
public class Ingrediente
{
    public int Id { get; set; }
    public string? Nombre { get; set; }
    public decimal  Precio { get; set;}
    public decimal Calorias {get; set;}

}
